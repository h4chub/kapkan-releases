package net.caffeinemc.mods.lithium.mixin.chunk.serialization;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import net.caffeinemc.mods.lithium.common.world.chunk.CompactingPackedIntegerArray;
import net.caffeinemc.mods.lithium.common.world.chunk.LithiumHashPalette;
import net.caffeinemc.mods.lithium.mixin.util.accessors.StrategyAccessor;
import net.minecraft.util.BitStorage;
import net.minecraft.util.SimpleBitStorage;
import net.minecraft.util.ZeroBitStorage;
import net.minecraft.world.level.chunk.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.IntConsumer;
import java.util.stream.LongStream;

/**
 * Makes a number of patches to {@link PalettedContainer} to speed up integer array compaction. While I/O operations
 * in Minecraft 1.15+ are handled off-thread, NBT serialization is not and happens on the main server thread.
 */
@Mixin(value = PalettedContainer.class, priority = 50 /*Apply mixin first to avoid replacing lambdas from other mods that wrap the original lambda*/)
public abstract class PalettedContainerMixin<T> {
    private static final ThreadLocal<short[]> CACHED_ARRAY_4096 = ThreadLocal.withInitial(() -> new short[4096]);
    private static final ThreadLocal<short[]> CACHED_ARRAY_64 = ThreadLocal.withInitial(() -> new short[64]);

    @Shadow
    public abstract void acquire();

    @Shadow
    protected abstract T get(int index);

    @Shadow
    private volatile PalettedContainer.Data<T> data;

    @Shadow
    public abstract void release();

    /**
     * This patch incorporates a number of changes to significantly reduce the time needed to serialize.
     * - If a palette only contains one entry, do not attempt to repack it
     * - The packed integer array is iterated over using a specialized consumer instead of a naive for-loop.
     * - A temporary fixed array is used to cache palette lookups and remaps while compacting a data array.
     * - If the palette didn't change after compaction, avoid the step of re-packing the integer array and instead do
     * a simple memory copy.
     *
     * @reason Optimize serialization
     * @author JellySquid
     */
    @Overwrite
    public PalettedContainerRO.PackedData<T> pack(Strategy<T> strategy) {
        this.acquire();

        // The palette that will be serialized
        LithiumHashPalette<T> hashPalette = null;
        Optional<LongStream> data = Optional.empty();
        List<T> elements = null;

        final Palette<T> palette = this.data.palette();
        final BitStorage storage = this.data.storage();
        if (storage instanceof ZeroBitStorage || palette.getSize() == 1) {
            // If the palette only contains one entry, don't attempt to repack it.
            elements = List.of(palette.valueFor(0));
        } else if (palette instanceof LithiumHashPalette<T> lithiumHashPalette) {
            hashPalette = lithiumHashPalette;
        }

        if (elements == null) {
            LithiumHashPalette<T> compactedPalette = new LithiumHashPalette<>(storage.getBits());
            short[] array = this.getOrCreate(strategy.entryCount());

            ((CompactingPackedIntegerArray) storage).lithium$compact(this.data.palette(), compactedPalette, array);

            // If the palette didn't change during compaction, do a simple copy of the data array
            Configuration origConfig;
            if (hashPalette != null && hashPalette.getSize() == compactedPalette.getSize() &&
                    !(origConfig = ((StrategyAccessor) strategy).lithium$getConfigurationForPaletteSize(hashPalette.getSize())).alwaysRepack() && storage.getBits() == origConfig.bitsInStorage()) { // paletteSize can de-sync from palette - see https://github.com/CaffeineMC/lithium-fabric/issues/279
                data = this.asOptional(storage.getRaw().clone());
                elements = hashPalette.getElements();
            } else {
                int bits = ((StrategyAccessor) strategy).lithium$getConfigurationForPaletteSize(compactedPalette.getSize()).bitsInStorage();
                if (bits != 0) {
                    // Re-pack the integer array as the palette has changed size
                    SimpleBitStorage copy = new SimpleBitStorage(bits, array.length);
                    for (int i = 0; i < array.length; ++i) {
                        copy.set(i, array[i]);
                    }

                    // We don't need to clone the data array as we are the sole owner of it
                    data = this.asOptional(copy.getRaw());
                }

                elements = compactedPalette.getElements();
            }
        }

        this.release();
        return new PalettedContainerRO.PackedData<>(elements, data);
    }

    private Optional<LongStream> asOptional(long[] data) {
        return Optional.of(Arrays.stream(data));
    }

    private short[] getOrCreate(int size) {
        return switch (size) {
            case 64 -> CACHED_ARRAY_64.get();
            case 4096 -> CACHED_ARRAY_4096.get();
            default -> new short[size];
        };
    }

    /**
     * If we know the palette will contain a fixed number of elements, we can make a significant optimization by counting
     * blocks with a simple array instead of a integer map. Since palettes make no guarantee that they are bounded,
     * we have to try and determine for each implementation type how many elements there are.
     * <p>
     * Original implementation (Complete method replacement) by JellySquid
     * Mod compatibility rewrite by 2No2Name
     *
     * @author JellySquid
     * @author 2No2Name
     */
    @WrapOperation(
            method = "count(Lnet/minecraft/world/level/chunk/PalettedContainer$CountConsumer;)V",
            at = @At(
                    value = "NEW",
                    target = "()Lit/unimi/dsi/fastutil/ints/Int2IntOpenHashMap;"
            )
    )
    private Int2IntOpenHashMap returnDummyInstance(Operation<Int2IntOpenHashMap> original) {
        int len = this.data.palette().getSize();

        // Do not allocate huge arrays if we're using a large palette
        if (len > 4096) {
            return original.call();
        }

        return null;
    }

    @ModifyArg(
            method = "count(Lnet/minecraft/world/level/chunk/PalettedContainer$CountConsumer;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/BitStorage;getAll(Ljava/util/function/IntConsumer;)V"
            )
    )
    private IntConsumer getFastCountingLambda(IntConsumer output, @Local(name = "counts") Int2IntOpenHashMap counts, @Share(value = "countsArray", namespace = "lithium") LocalRef<short[]> countsRef) {

        // Do not allocate huge arrays if we're using a large palette
        if (counts != null) {
            return output;
        }

        //This mixin should be applied first for mod compatibility reasons
        short[] countsArray = new short[this.data.palette().getSize()];
        countsRef.set(countsArray);
        return i -> countsArray[i]++;
    }

    @Inject(
            method = "count(Lnet/minecraft/world/level/chunk/PalettedContainer$CountConsumer;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lit/unimi/dsi/fastutil/ints/Int2IntOpenHashMap;int2IntEntrySet()Lit/unimi/dsi/fastutil/ints/Int2IntMap$FastEntrySet;"
            ), cancellable = true
    )
    private void fastForEachAndCancelMethod(PalettedContainer.CountConsumer<T> output, CallbackInfo ci, @Local(name = "counts") Int2IntOpenHashMap counts, @Share(value = "countsArray", namespace = "lithium") LocalRef<short[]> countsRef) {
        if (counts == null) {
            ci.cancel();
            short[] countsArray = Objects.requireNonNull(countsRef.get());
            for (int i = 0; i < countsArray.length; i++) {
                output.accept(this.data.palette().valueFor(i), countsArray[i]);
            }
        }
    }
}
